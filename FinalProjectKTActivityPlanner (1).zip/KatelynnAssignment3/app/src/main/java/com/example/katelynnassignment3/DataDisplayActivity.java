package com.example.katelynnassignment3;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class DataDisplayActivity extends AppCompatActivity {

    private GridView mGridView;
    private DataGridAdapter mAdapter;
    private ArrayList<String> mDataList;
    private DatabaseHelper mDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        mDatabaseHelper = new DatabaseHelper(this);

        // Initialize data list from database
        mDataList = new ArrayList<>();
        Cursor cursor = mDatabaseHelper.getAllData();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                mDataList.add(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_ACTIVITY_NAME)));
            } while (cursor.moveToNext());
            cursor.close();
        }

        // Initialize GridView and set adapter
        mGridView = findViewById(R.id.gridView);
        mAdapter = new DataGridAdapter(this, mDataList);
        mGridView.setAdapter(mAdapter);

        // Set onClickListener for Add button
        Button btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Logic to add new data row
                String newData = "New Data"; // Example: Add new data
                if (mDatabaseHelper.insertData(newData)) {
                    mDataList.add(newData);
                    mAdapter.notifyDataSetChanged(); // Notify adapter
                }
            }
        });

        // Set onClickListener for Remove button
        Button btnRemove = findViewById(R.id.btnRemove);
        btnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Logic to remove data row
                if (!mDataList.isEmpty()) {
                    Cursor cursor = mDatabaseHelper.getAllData();
                    if (cursor != null && cursor.moveToLast()) {
                        int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ACTIVITY_ID));
                        if (mDatabaseHelper.deleteData(id)) {
                            mDataList.remove(mDataList.size() - 1);
                            mAdapter.notifyDataSetChanged();
                        }
                        cursor.close();
                    }
                }
            }
        });

        // Example: Handle item click (if needed)
        mGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Handle item click
            }
        });
    }
}
