package com.example.katelynnassignment3;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Calendar;

public class ActivityPlannerActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private EditText editTextActivity;
    private RecyclerView recyclerViewActivities;
    private ArrayList<ActivityItem> activitiesList;
    private ActivitiesAdapter adapter;
    private DatabaseHelper databaseHelper;
    private String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planner);

        databaseHelper = new DatabaseHelper(this);

        calendarView = findViewById(R.id.calendarView);
        editTextActivity = findViewById(R.id.editTextActivity);
        recyclerViewActivities = findViewById(R.id.recyclerViewActivities);

        activitiesList = new ArrayList<>();
        adapter = new ActivitiesAdapter(this, activitiesList, databaseHelper);
        recyclerViewActivities.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewActivities.setAdapter(adapter);

        selectedDate = getCurrentDate();
        loadActivities(selectedDate);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth);
            loadActivities(selectedDate);
        });

        findViewById(R.id.buttonAddActivity).setOnClickListener(v -> {
            String activity = editTextActivity.getText().toString().trim();
            if (!activity.isEmpty()) {
                if (databaseHelper.insertActivity(activity, selectedDate)) {
                    // Get the ID of the newly inserted activity
                    Cursor cursor = databaseHelper.getActivitiesByDate(selectedDate);
                    if (cursor != null && cursor.moveToLast()) {
                        int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ACTIVITY_ID));
                        activitiesList.add(new ActivityItem(id, activity));
                        cursor.close();
                    }
                    adapter.notifyDataSetChanged();
                    editTextActivity.setText("");
                    Toast.makeText(ActivityPlannerActivity.this, "Activity added", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ActivityPlannerActivity.this, "Failed to add activity", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(ActivityPlannerActivity.this, "Please enter an activity", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadActivities(String date) {
        activitiesList.clear();
        Cursor cursor = databaseHelper.getActivitiesByDate(date);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ACTIVITY_ID));
                String activityName = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_ACTIVITY_NAME));
                activitiesList.add(new ActivityItem(id, activityName));
            } while (cursor.moveToNext());
            cursor.close();
            adapter.notifyDataSetChanged();
        }
    }

    private String getCurrentDate() {
        Calendar calendar = Calendar.getInstance();
        return String.format("%04d-%02d-%02d", calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH));
    }
}

