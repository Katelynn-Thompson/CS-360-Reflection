package com.example.katelynnassignment3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class ActivitiesAdapter extends RecyclerView.Adapter<ActivitiesAdapter.ViewHolder> {

    private final Context mContext;
    private final ArrayList<ActivityItem> mActivitiesList;
    private final DatabaseHelper mDatabaseHelper;

    public ActivitiesAdapter(Context context, ArrayList<ActivityItem> activitiesList, DatabaseHelper databaseHelper) {
        this.mContext = context;
        this.mActivitiesList = activitiesList;
        this.mDatabaseHelper = databaseHelper;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.activity_item_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ActivityItem activityItem = mActivitiesList.get(position);
        holder.textViewActivity.setText(activityItem.getActivityName());

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mDatabaseHelper.deleteActivity(activityItem.getId())) {
                    mActivitiesList.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, mActivitiesList.size());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mActivitiesList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewActivity;
        ImageButton btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewActivity = itemView.findViewById(R.id.textViewActivity);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
