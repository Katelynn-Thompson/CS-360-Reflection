package com.example.katelynnassignment3;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsNotificationActivity extends AppCompatActivity {

    private static final int REQUEST_SMS_PERMISSION = 100;
    private Switch switchSmsNotifications;
    private Switch switchEmailNotifications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        switchSmsNotifications = findViewById(R.id.switchSmsNotifications);
        switchEmailNotifications = findViewById(R.id.switchEmailNotifications);

        // Load the saved preferences for the switches
        loadPreferences();

        // Set listeners for the switches
        switchSmsNotifications.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                if (!isSmsPermissionGranted()) {
                    requestSmsPermission();
                } else {
                    savePreferences();
                    sendTestSms(); // Send a test SMS to confirm functionality
                }
            } else {
                // Handle SMS notifications disable logic
                savePreferences();
            }
        });

        switchEmailNotifications.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Handle email notifications enable/disable logic
            savePreferences();
        });
    }

    public void onRequestPermission(View view) {
        if (isSmsPermissionGranted()) {
            Toast.makeText(this, "SMS Permission is already granted.", Toast.LENGTH_SHORT).show();
        } else {
            requestSmsPermission();
        }
    }

    private boolean isSmsPermissionGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSmsPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!isSmsPermissionGranted()) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        REQUEST_SMS_PERMISSION);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted. Automated notifications will be sent.", Toast.LENGTH_SHORT).show();
                savePreferences();
                sendTestSms(); // Send a test SMS to confirm functionality
            } else {
                Toast.makeText(this, "SMS Permission Denied. Notifications will not be sent.", Toast.LENGTH_SHORT).show();
                switchSmsNotifications.setChecked(false); // Reset switch state
            }
        }
    }

    private void loadPreferences() {
        boolean smsEnabled = getPreferences(MODE_PRIVATE).getBoolean("sms_notifications", false);
        boolean emailEnabled = getPreferences(MODE_PRIVATE).getBoolean("email_notifications", false);
        switchSmsNotifications.setChecked(smsEnabled);
        switchEmailNotifications.setChecked(emailEnabled);
    }

    private void savePreferences() {
        getPreferences(MODE_PRIVATE)
                .edit()
                .putBoolean("sms_notifications", switchSmsNotifications.isChecked())
                .putBoolean("email_notifications", switchEmailNotifications.isChecked())
                .apply();
    }

    private void sendTestSms() {
        if (isSmsPermissionGranted()) {
            String phoneNumber = "1234567890"; // Replace with actual phone number
            String message = "This is a test SMS from the app.";

            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "Test SMS sent.", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS.", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }
    }
}
