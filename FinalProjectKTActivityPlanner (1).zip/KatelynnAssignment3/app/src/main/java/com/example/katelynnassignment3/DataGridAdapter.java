package com.example.katelynnassignment3;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import java.util.ArrayList;

public class DataGridAdapter extends BaseAdapter {

    private final Context mContext;
    private final ArrayList<String> mDataList;

    public DataGridAdapter(Context context, ArrayList<String> dataList) {
        this.mContext = context;
        this.mDataList = dataList;
    }

    @Override
    public int getCount() {
        return mDataList.size();
    }

    @Override
    public Object getItem(int position) {
        return mDataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.grid_item_layout, parent, false);
            holder = new ViewHolder();
            holder.textViewLabel = convertView.findViewById(R.id.textViewLabel);
            holder.editTextData = convertView.findViewById(R.id.editTextData);
            holder.btnDelete = convertView.findViewById(R.id.btnDelete);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        // Bind data to UI elements
        holder.textViewLabel.setText("Item " + (position + 1));
        holder.editTextData.setText(mDataList.get(position));

        // Handle delete button click
        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHelper dbHelper = new DatabaseHelper(mContext);
                Cursor cursor = dbHelper.getAllData();
                if (cursor != null && cursor.moveToPosition(position)) {
                    int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ACTIVITY_ID));
                    if (dbHelper.deleteData(id)) {
                        mDataList.remove(position);
                        notifyDataSetChanged();
                    }
                    cursor.close();
                }
            }
        });

        return convertView;
    }

    static class ViewHolder {
        TextView textViewLabel;
        EditText editTextData;
        ImageButton btnDelete;
    }
}
