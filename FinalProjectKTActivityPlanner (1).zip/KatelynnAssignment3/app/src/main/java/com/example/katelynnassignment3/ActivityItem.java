package com.example.katelynnassignment3;

public class ActivityItem {
    private int id;
    private String activityName;

    public ActivityItem(int id, String activityName) {
        this.id = id;
        this.activityName = activityName;
    }

    public int getId() {
        return id;
    }

    public String getActivityName() {
        return activityName;
    }
}
